# Payroll Form Downloads

These public-safe templates are adapted from the user-provided monthly and annual formats. Company names, TINs, employee names, identity numbers, contact details, and sample payroll amounts were removed or replaced with placeholders.

They are preparation templates only; verify the current official IRD and SSB forms, rules, and submission requirements before filing.
